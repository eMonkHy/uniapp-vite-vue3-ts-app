import Vue from "vue";
import signMd5Utils from "@/utils/encryption/signMd5Utils";
import service from "./request";
import { 接口返回对象 } from "./services/systemService";
import { AxiosResponse, Method } from "axios";

const api = {
  user: "/mock/api/user",
  role: "/mock/api/role",
  service: "/mock/api/service",
  permission: "/mock/api/permission",
  permissionNoPager: "/mock/api/permission/no-pager",
};

export default api;

//post
export function postAction<T>(url:string, parameter:any) : Promise<接口返回对象<T>>{
  let sign = signMd5Utils.getSign(url, parameter);
  //将签名和时间戳，添加在请求接口 Header
  let signHeader = {
    "X-Sign": sign,
    "X-TIMESTAMP": signMd5Utils.getDateTimeToString(),
  };

  return service({
    url: url,
    method: "post",
    data: parameter,
    headers: signHeader,
  });
}

//post method= {post | put}
export function httpAction(url, parameter, method:Method) {
  let sign = signMd5Utils.getSign(url, parameter);
  //将签名和时间戳，添加在请求接口 Header
  let signHeader = {
    "X-Sign": sign,
    "X-TIMESTAMP": signMd5Utils.getDateTimeToString(),
  };

  return service({
    url: url,
    method: method,
    data: parameter,
    headers: signHeader,
  });
}

//put
export function putAction<T>(
  url: string,
  parameter: any
): Promise<接口返回对象<T>> {
  return service({
    url: url,
    method: "put",
    data: parameter,
  });
}

//get
export function getAction<T>(
  url: string,
  parameter: any
): Promise<接口返回对象<T>> {
  let sign = signMd5Utils.getSign(url, parameter);
  //将签名和时间戳，添加在请求接口 Header
  let signHeader = {
    "X-Sign": sign,
    "X-TIMESTAMP": signMd5Utils.getDateTimeToString(),
  };

  return service({
    url: url,
    method: "get",
    params: parameter,
    headers: signHeader,
  });
}

//post
export function postFormAction(url, parameter) {
  let sign = signMd5Utils.getSign(url, parameter);
  //将签名和时间戳，添加在请求接口 Header
  let signHeader = {
    "X-Sign": sign,
    "X-TIMESTAMP": signMd5Utils.getDateTimeToString(),
  };

  return service({
    url: url,
    method: "post",
    params: parameter,
    headers: signHeader,
  });
}

//deleteAction
export function deleteAction(url, parameter): Promise<接口返回对象<any>> {
  return service({
    url: url,
    method: "delete",
    params: parameter,
  });
}

export function getUserList(parameter) {
  return service({
    url: api.user,
    method: "get",
    params: parameter,
  });
}

export function getRoleList(parameter) {
  return service({
    url: api.role,
    method: "get",
    params: parameter,
  });
}

export function getServiceList(parameter) {
  return service({
    url: api.service,
    method: "get",
    params: parameter,
  });
}

export function getPermissions(parameter) {
  return service({
    url: api.permissionNoPager,
    method: "get",
    params: parameter,
  });
}

// id == 0 add     post
// id != 0 update  put
export function saveService(parameter) {
  return service({
    url: api.service,
    method: parameter.id == 0 ? "post" : "put",
    data: parameter,
  });
}

/**
 * 下载文件 用于excel导出
 * @param url
 * @param parameter
 * @returns {*}
 */
export function downFile(url, parameter) {
  return service({
    url: url,
    params: parameter,
    method: "get",
    responseType: "blob",
  });
}
export function downFilePost(url, parameter) {
  return service({
    url: url,
    data: parameter,
    method: "post",
    responseType: "blob",
  });
}

/**
 * 文件上传 用于富文本上传图片
 * @param url
 * @param parameter
 * @returns {*}
 */
export function uploadAction(url, parameter) {
  return service({
    url: url,
    data: parameter,
    method: "post",
    headers: {
      "Content-Type": "multipart/form-data", // 文件上传
    },
  });
}
 
