import Vue from "vue";
import axios from "axios";
import { useUserPinia } from "@/pinia/modules/userPinia";
import { getAuthCache } from "@/utils/auth";
import { TENANT_ID, TOKEN_KEY } from "@/enums/cacheEnum";
import { getAppEnvConfig, isMockMode } from "@/utils/env";
import { reloadPage } from "@/utils/uniappUtils";
/**是否模拟模式 */
const flagMockMode = isMockMode();

const env = getAppEnvConfig();

/**
 * 【指定 axios的 baseURL】
 * 如果手工指定 baseURL: '/ande-boot'
 * 则映射后端域名，通过 vue.config.js
 * @type {*|string}
 */
let apiBaseUrl = env.VITE_GLOB_DOMAIN_URL || "/ande-boot";
console.log('%c [ apiBaseUrl ]-21', 'font-size:13px; background:#b75d81; color:#fba1c5;', apiBaseUrl)

// 创建 axios 实例
const service = axios.create({
  //baseURL: '/ande-boot',
  baseURL: apiBaseUrl, // api base_url
  timeout: 20000, // 请求超时时间
});

const err = (error) => {
  if (error.response) {
    let data = error.response.data;
    const token = getAuthCache(TOKEN_KEY);
    switch (error.response.status) {
      case 403:
        // notification.error({
        //   message: "系统提示",
        //   description: "拒绝访问",
        //   duration: 4,
        // });
        break;
      case 500:
        if (flagMockMode) {
          break;
        }
        // update-begin- --- author:liusq ------ date:20200910 ---- for:处理Blob情况----
        let type = error.response.request.responseType;
        if (type === "blob") {
          blobToJson(data);
        }
        // update-end- --- author:liusq ------ date:20200910 ---- for:处理Blob情况----
        if (token) {
          if (data.message.includes("Token失效")) {
            if (/wxwork|dingtalk/i.test(navigator.userAgent)) {
              // message.loading("登录已过期，正在重新登陆", 0);
            } else {
              // Modal.confirm({
              //   title: "登录已过期",
              //   content: "很抱歉，登录已过期，请重新登录",
              //   okText: "重新登录",
              //   okButtonProps: { loading: useUserPinia().logOutLoading },
              //   cancelText: "取消",
              //   mask: false,
              //   onOk: () => {
              //     useUserPinia()
              //       .logOut()
              //       .then(() => {
              //         try {
              //           const paths = getCurrentPages();
              //           console.log('%c [ paths ]-70', 'font-size:13px; background:#8ccdee; color:#d0ffff;', paths)

              //           // let path = window.document.location.pathname;
              //           // if (path != "/" && path.indexOf("/user/login") == -1) {
              //           //   window.location.reload();
              //           // }
              //         } catch (e) {
              //           // window.location.reload();
              //         }
              //       })
              //       .finally(() => {
              //         Modal.destroyAll();
              //       });
              //   },
              // });
            }
          }
          // update-begin- --- author:zw ------ date:20190225 ---- for:Token失效采用弹框模式，不直接跳转----

          // for:Token失效采用弹框模式，不直接跳转
        } else {
          // Modal.confirm({
          //   title: "登录已过期",
          //   content: "很抱歉，登录已过期，请重新登录",
          //   okText: "重新登录",
          //   cancelText: "取消",
          //   mask: false,
          //   onOk: () => {
          //     useUserPinia().logOut();
          //     try {
          //       let path = window.document.location.pathname;
          //       if (path != "/" && path.indexOf("/user/login") == -1) {
          //         window.location.reload();
          //       }
          //       Modal.destroyAll();
          //     } catch (e) {
          //       window.location.reload();
          //     }
          //   },
          // });
        }
        break;
      case 404:
        // notification.error({
        //   message: "系统提示",
        //   description: "很抱歉，资源未找到!",
        //   duration: 4,
        // });
        break;
      case 504:
        // notification.error({ message: "系统提示", description: "网络超时" });
        break;
      case 401:
        // notification.error({
        //   message: "系统提示",
        //   description: "未授权，请重新登录",
        //   duration: 4,
        // });
        if (token) {
          useUserPinia()
            .logOut()
            .then(() => {
              setTimeout(() => {
                // window.location.reload();
                // #ifdef APP-PLUS
                reloadPage()
                // #endif
              }, 1500);
            });
        }
        break;
      default:
        if (!flagMockMode) {
          // notification.error({
          //   message: "系统提示",
          //   description: "404,技术人员正在赶来！",
          //   duration: 4,
          // });
        }
        break;
    }
  } else if (error.message) {
    if (error.message.includes("timeout")) {
      // notification.error({ message: "系统提示", description: "网络超时" });
    } else {
      if (!flagMockMode) {
        // notification.error({
        //   message: "系统提示",
        //   description: "4000,技术人员正在赶来！",
        // });
      }
    }
  }
  return Promise.reject(error);
};

// request interceptor
service.interceptors.request.use(
  (config) => {
    if (config.url.indexOf("_mock") >= 0) {
      config.baseURL = "";
    } else {
      let token = getAuthCache(TOKEN_KEY);
      if (token) {
        config.headers["X-Access-Token"] = token; // 让每个请求携带自定义 token 请根据实际情况自行修改
      }

      // update-begin--author:sunjianlei---date:20200723---for 如果当前在low-app环境，并且携带了appId，就向Header里传递appId
      // const pages = 
      // const $route = router.currentRoute;
      // if ($route && $route.value.name && $route.value.params.appId) {
      //   config.headers["X-Low-App-ID"] = $route.value.params.appId;
      // }
      // update-end--author:sunjianlei---date:20200723---for 如果当前在low-app环境，并且携带了appId，就向Header里传递appId

      //update-begin-author:taoyan date:2020707 for:多租户
      let tenantid = getAuthCache(TENANT_ID);
      if (!tenantid) {
        tenantid = 0;
      }
      config.headers["tenant-id"] = tenantid;
      //update-end-author:taoyan date:2020707 for:多租户
      if (config.method == "get") {
        if (config.url.indexOf("sys/dict/getDictItems") < 0) {
          config.params = {
            _t: Date.parse(new Date()) / 1000,
            ...config.params,
          };
        }
      }
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// response interceptor
service.interceptors.response.use((response) => {
  return response.data;
}, err);


/**
 * Blob解析
 * @param data
 */
function blobToJson(data) {
  let fileReader = new FileReader();
  let token = getAuthCache(TOKEN_KEY);
  fileReader.onload = function () {
    try {
      let jsonData = JSON.parse(this.result); // 说明是普通对象数据，后台转换失败
      if (jsonData.status === 500) {
        if (token && jsonData.message.includes("Token失效")) {
          // Modal.error({
          //   title: "登录已过期",
          //   content: "很抱歉，登录已过期，请重新登录",
          //   okText: "重新登录",
          //   cancelText: "取消",
          //   okButtonProps: { loading: useUserPinia().logOutLoading },
          //   mask: false,
          //   onOk: () => {
          //     useUserPinia()
          //       .logOut()
          //       .then(() => {
          //         window.location.reload();
          //       })
          //       .finally(() => {
          //         Modal.destroyAll();
          //       });
          //   },
          // });
        }
      }
    } catch (err) {
      // 解析成对象失败，说明是正常的文件流
    }
  };
  fileReader.readAsText(data);
}

export default service;
