import type {
  AxiosRequestConfig,
  AxiosInstance,
  AxiosResponse,
  AxiosError,
} from 'axios'
import { isFunction } from '@/utils/is'
import { cloneDeep } from 'lodash-es'
import {  } from '@/hooks/settings'
import { useMessage } from '@/hooks/useMessage'
import { ContentTypeEnum, RequestEnum } from '@/enums'
import service from '@/api/request'
import { getConfigs, axios } from './serviceOptions'
import { 接口返回对象 } from './systemService'
import { getAppEnvConfig } from '@/utils/env'
const env=getAppEnvConfig()
const { createMessage } = useMessage()

/**
 * @description:  axios module
 */
export class AndeAxios {
  private axiosInstance: AxiosInstance
  private readonly options: IRequestConfig

  constructor(options: IRequestConfig) {
    this.options = options
    this.axiosInstance = service
  }

  /**
   * @description:  Create axios instance
   */
  private createAxios(config: IRequestConfig): void {
    this.axiosInstance = service
  }

  getAxios(): AxiosInstance {
    return this.axiosInstance
  }

  /**
   * @description: Reconfigure axios
   */
  configAxios(config: IRequestConfig) {
    if (!this.axiosInstance) {
      return
    }
    this.createAxios(config)
  }

  /**
   * @description: Set general header
   */
  setHeader(headers: any): void {
    if (!this.axiosInstance) {
      return
    }
    Object.assign(this.axiosInstance.defaults.headers, headers)
  }

  /**
   * 文件上传
   */
  //--@updateBy-begin----author:liusq---date:20211117------for:增加上传回调参数callback------
  uploadFile<T = any>(
    config: AxiosRequestConfig,
    params: UploadFileParams,
    callback?: UploadFileCallBack
  ) {
    //--@updateBy-end----author:liusq---date:20211117------for:增加上传回调参数callback------
	// FormData();
    const formData = new window.FormData()
    const customFilename = params.name || 'file'

    if (params.filename) {
      formData.append(customFilename, params.file, params.filename)
    } else {
      formData.append(customFilename, params.file)
    }
    config.baseURL = env.VITE_GLOB_UPLOAD_URL
    if (params.data) {
      Object.keys(params.data).forEach((key) => {
        const value = params.data![key]
        if (Array.isArray(value)) {
          value.forEach((item) => {
            formData.append(`${key}[]`, item)
          })
          return
        }

        formData.append(key, params.data[key])
      })
    }

    return this.axiosInstance
      .request<T>({
        ...config,
        method: 'POST',
        data: formData,
        headers: {
          'Content-type': ContentTypeEnum.FORM_DATA,
          ignoreCancelToken: true,
        },
      })
      .then((res: 接口返回对象<T>) => {
        if (callback?.success && isFunction(callback?.success)) {
          callback?.success(res);
          //--@updateBy-end----author:liusq---date:20210914------for:上传判断是否包含回调方法------
        } else if (callback?.isReturnResponse) {
          //--@updateBy-begin----author:liusq---date:20211117------for:上传判断是否返回res信息------
          return Promise.resolve(res?.result);
          //--@updateBy-end----author:liusq---date:20211117------for:上传判断是否返回res信息------
        } else {
          if (res.success == true && res.code == 200) {
            createMessage.success(res.message);
          } else {
            createMessage.error(res.message);
          }
        }
      })
  }

  // 支持表单数据 
  supportFormData(config: AxiosRequestConfig) {
    const headers = config.headers || this.options.headers
    const contentType = headers?.['Content-Type'] || headers?.['content-type']

    if (
      contentType !== ContentTypeEnum.FORM_URLENCODED ||
      !Reflect.has(config, 'data') ||
      config.method?.toUpperCase() === RequestEnum.GET
    ) {
      return config
    }

    return {
      ...config,
      // data: qs.stringify(config.data, { arrayFormat: 'brackets' }),
    }
  }

  get<T = any>(
    config: AxiosRequestConfig,
    options?: IRequestOptions
  ): Promise<T> {
    return this.request({ ...config, method: 'GET' }, options)
  }

  post<T = any>(
    config: AxiosRequestConfig,
    options?: IRequestOptions
  ): Promise<T> {
    return this.request({ ...config, method: 'POST' }, options)
  }

  put<T = any>(
    config: AxiosRequestConfig,
    options?: IRequestOptions
  ): Promise<T> {
    return this.request({ ...config, method: 'PUT' }, options)
  }

  delete<T = any>(
    config: AxiosRequestConfig,
    options?: IRequestOptions
  ): Promise<T> {
    return this.request({ ...config, method: 'DELETE' }, options)
  }

  request<T = any>(
    config: AxiosRequestConfig,
    options?: IRequestOptions
  ): Promise<T> {
    let conf: IRequestConfig = cloneDeep(config)
    conf.headers = {
      'Content-type': ContentTypeEnum.JSON,

      ...config,
      ...options?.headers,
    }
    return new Promise((resolve, reject) => {
      return this.axiosInstance
        .request(conf)
        .then((res) => {
          resolve(res as unknown as Promise<T>)
        })
        .catch((err) => {
          console.log('request fail:', err)
          reject(err)
        })
    })
  }

  /**
   * 【用于评论功能】自定义文件上传-请求
   * @param url
   * @param formData
   */
  uploadMyFile<T = any>(url, formData) {
    
    return this.axiosInstance.request<T>({
      url: url,
      baseURL: env.VITE_GLOB_UPLOAD_URL,
      method: 'POST',
      data: formData,
      headers: {
        'Content-type': ContentTypeEnum.FORM_DATA,
        ignoreCancelToken: true,
      },
    })
  }
}
