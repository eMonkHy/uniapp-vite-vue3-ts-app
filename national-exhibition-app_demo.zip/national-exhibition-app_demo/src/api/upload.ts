/*
 * @Author: zhangwei
 * @Date: 2023-04-28 21:55:21
 * @Description:
 */
import { getAppEnvConfig } from "@/utils/env";
import { andeAxios } from ".";

let uploadUrl: string = "";
const env = getAppEnvConfig();
if (env.VITE_GLOB_UPLOAD_URL) {
  uploadUrl = env.VITE_GLOB_UPLOAD_URL;
}
/**
 * @description: Upload interface
 */
export function uploadApi(
  params: UploadFileParams,
  onUploadProgress: (progressEvent: ProgressEvent) => void
) {
  console.log(
    "%c [ uploadApi ]-15",
    "font-size:13px; background:#e1841a; color:#ffc85e;",
    uploadApi
  );
  return andeAxios().uploadFile<UploadApiResult>(
    {
      url: `${uploadUrl}/sys/common/upload`,
    },
    params,
    { success: onUploadProgress }
  );
}
/**
 * @description: Upload interface
 */
export function uploadImg(
  params: UploadFileParams,
  onUploadProgress: (progressEvent: ProgressEvent) => void
) {
  return andeAxios().uploadFile<UploadApiResult>(
    {
      url: `${uploadUrl}/sys/common/upload`,
    },
    params,
    { success: onUploadProgress }
  );
}
export function uploadVideo(
  params: UploadFileParams,
  onUploadProgress: (progressEvent: ProgressEvent) => void
) {
  return andeAxios({ timeout: 6000 * 60 * 2 }).uploadFile<UploadApiResult>(
    {
      url: `${uploadUrl}/sys/common/upload`,
    },
    params,
    { success: onUploadProgress }
  );
}
/**
 * @description: Upload interface
 */
export function zw_upload(
  params: UploadFileParams & { url: string },
  onUploadProgress: (progressEvent: ProgressEvent) => void
) {
  console.log(
    "%c [ params ]-21",
    "font-size:13px; background:#7b9313; color:#bfd757;",
    params
  );
  return andeAxios().uploadFile<UploadApiResult>(
    {
      url: params.url,
    },
    params,
    { success: onUploadProgress }
  );
}
