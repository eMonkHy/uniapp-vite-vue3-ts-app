/**
 * 权限枚举
 */
export enum EnumPermission {
  "系统配置新增" = "sysconfig:add",
  
}