export enum EnumVisitorStatus {
  未审核 = "未审核",
  审核中 = "审核中",
  审核通过 = "审核通过",
  审核不通过 = "审核不通过",
  已到访 = "已到访",
}
