/*
 * @Author: 张伟
 * @Date: 2023-05-29 12:33:42
 * @Description: 
 */
import { nextTick, onMounted, onActivated } from 'vue';

export function useOnMountedOrActivated(hook: Function) {
  let mounted: boolean;

  onMounted(() => {
    hook();
    nextTick(() => {
      mounted = true;
    });
  });

  onActivated(() => {
    if (mounted) {
      hook();
    }
  });
}
