/*
 * @Author: 张伟
 * @Date: 2023-05-25 10:05:36
 * @Description:
 */

import type { Dayjs } from 'dayjs'
type RangeValue = [any, any]
/**
 * 时间范围range
 * @param date1 时间1
 * @param date2 时间2
 */
export function useRangePicker<T>(
  model: Ref<T>,
  date1Prop: keyof T,
  date2Prop: keyof T
) {
  console.log(
    '%c [ model ]-15',
    'font-size:13px; background:#acd3ec; color:#f0ffff;',
    model
  )
  console.log(
    '%c [ model.value[date1Prop] ]-16',
    'font-size:13px; background:#ae0a9d; color:#f24ee1;',
    model.value[date1Prop]
  )

  let model_range = ref<RangeValue | undefined>([
    model.value[date1Prop],
    model.value[date2Prop],
  ])
  /**
   * 初始化
   */
  const init = () => {
    model_range.value =  [
      model.value[date1Prop],
      model.value[date2Prop],
    ]
  }

watch(model, (newVal,oldVal) => {
    if (newVal) {



       init()
    }
  })
  watch(model_range, (newVal,oldVal) => {
    if (newVal) {



      model.value[date1Prop] = newVal[0]
      model.value[date2Prop] = newVal[1]
    }
  })

  return {
    model_range,
    init
  }
}
