import { AntdDesignForm ,useDesignForage} from "devops-form";
/**
 * 
 */
export const the_useDesignForage=useDesignForage()