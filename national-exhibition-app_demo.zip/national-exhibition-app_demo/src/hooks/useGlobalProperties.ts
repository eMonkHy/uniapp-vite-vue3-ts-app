/*
 * @Author: zhangwei
 * @Date: 2023-06-29 16:02:23
 * @Description:
 */
import { USER_NAME } from "@/enums";
import { getAuthCache } from "@/utils/auth";
import { getAppEnvConfig } from "@/utils/env";
import type { App } from "vue";
const { VITE_GLOB_ADMIN, VITE_GLOB_DEBUG_USERS, DEV } = getAppEnvConfig();

/**
 * 注册挂载全局属性
 * @param app
 */
export function setupGlobalProperties(app: App) {
  app.config.globalProperties.$admin = VITE_GLOB_ADMIN?.includes(
    getAuthCache(USER_NAME)
  );
  app.config.globalProperties.$isDev = DEV;
  app.config.globalProperties.$isKfAdmin = getAuthCache(USER_NAME)=='kfadmin';
  console.log('%c [ getAuthCache(USER_NAME) ]-22', 'font-size:13px; background:#0a885b; color:#4ecc9f;', getAuthCache(USER_NAME))
  app.config.globalProperties.$env = getAppEnvConfig();
}
