/**
 * indexdb服务
 * @param a_dataBaseName 数据库名称
 */
export function useIndexDB(a_dataBaseName: string) {
  let the_dataBase: IDBDatabase | undefined
  let the_storeName: string = ''
  /**
   * 打开/创建数据库
 
   * @param {string} storeName 仓库名称
   * @param {string} version 数据库的版本
   * @param {string} keyPath 主键键值，不传就自动创建主键
   * @param {Array} index 索引数组
   * @return {object} 该函数会返回一个数据库实例
   */
  type StoreOptions = {
    autoIncrement: boolean
    keyPath?: string
  }
  const openDB = function (
    version: number,
    a_storeName: string,
    a_keyPath?: string,
    index?: Array<any[]> | undefined
  ): Promise<{
    /**
     * 0成功|1失败
     */
    code: number
    success: boolean
    /**
     * database 数据库对象
     */
    data: IDBDatabase | undefined
    msg: string
  }> {
    the_storeName = a_storeName
    return new Promise((resolve, reject) => {
      //  兼容浏览器
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      const { webkitIndexedDB, indexedDB, mozIndexedDB, msIndexedDB } = window
      const indexDB =
        indexedDB || mozIndexedDB || webkitIndexedDB || msIndexedDB
      the_dataBase = undefined
      const request = indexDB.open(a_dataBaseName, version)
      // 操作成功
      request.onsuccess = function (event: any) {
        the_dataBase = event?.target?.result // 数据库对象
        console.log('====================数据库打开成功=============================')
        resolve({
          code: 0,
          success: true,
          data: the_dataBase,
          msg: '数据库打开成功!',
        })
      }
      // 操作失败
      request.onerror = function () {
        console.log('====================数据库打开失败=============================')

        resolve({
          code: -1,
          success: false,
          data: undefined,
          msg: '数据库打开失败!',
        })
      }
      // 创建表和索引
      request.onupgradeneeded = function (event: any) {
        console.log('====================数据库创建或升级的时候会触发=============================')

        // 数据库创建或升级的时候会触发
        the_dataBase = event?.target?.result // 数据库对象
        const storeOptions: StoreOptions = {
          autoIncrement: true,
        }
        if (a_keyPath && a_keyPath !== '') {
          storeOptions.autoIncrement = false
          storeOptions.keyPath = a_keyPath
        }
        // 创建表
        if (!the_dataBase?.objectStoreNames.contains(a_storeName)) {
          const store = the_dataBase?.createObjectStore(
            a_storeName,
            storeOptions
          )
          // 创建索引
          // indexName索引列名称
          // indexKey索引键值
          if (index && index.length > 0) {
            index.forEach((item: any) => {
              if (
                !item.indexName ||
                !item.indexKey ||
                item.options.unique === undefined
              ) {
                reject(
                  "索引格式错误，请参照格式{indexName:'indexName',indexKey:'indexKey',{unique: false}}"
                )
              }
              store?.createIndex(item.indexName, item.indexKey, item.options)
            })
          }
        }
      }
    })
  }

  /**
   * 新增数据
   * @param {object} dataConfig 添加的数据集合
   **/
  const addData = function (dataConfig: any) {
    return new Promise((resolve, reject) => {
      if (!the_dataBase) {
        reject('数据库不存在或没有初始化')
      }
      if (!dataConfig || !dataConfig.value) {
        reject("value是必传项，参照格式{[keyPath]:'key',value:'value'}")
      }
      const req = the_dataBase!
        .transaction([the_storeName], 'readwrite')
        .objectStore(the_storeName) // 仓库对象
        .add(dataConfig)
      // 操作成功
      req.onsuccess = function () {
        resolve({ code: 0, success: true, data: null, msg: '数据写入成功!' })
      }
      // 操作失败
      req.onerror = function () {
        const data = {
          code: -1,
          success: false,
          data: null,
          msg: '数据写入失败!',
        }
        resolve(data)
      }
    })
  }

  /**
   * 更新数据
   * @param {string} storeName 仓库名称
   * @param {object} dataConfig 更新的数据集合
   */
  const updateData = function (dataConfig: Record<string,string>&{value:string}) {
    return new Promise((resolve, reject) => {
      if (!the_dataBase) {
        reject('数据库不存在或没有初始化')
      }
      if (!dataConfig || !dataConfig.value) {
        reject("value是必传项，参照格式{[keyPath]:'key',value:'value'}")
      }
      const req = the_dataBase!
        .transaction([the_storeName], 'readwrite')
        .objectStore(the_storeName)
        .put(dataConfig)
      // 操作成功
      req.onsuccess = function () {
        resolve({ code: 0, success: true, data: null, msg: '数据更新成功!' })
      }
      // 操作失败
      req.onerror = function () {
        const data = {
          code: -1,
          success: false,
          data: null,
          msg: '数据更新失败!',
        }
        resolve(data)
      }
    })
  }

  /**
   * 查询数据
   * @param {string} key 数据主键
   **/
  const getData = function (key: IDBKeyRange | IDBValidKey):Promise<{
    /**
     * 0成功|1失败
     */
    code: number
    success: boolean
    /**
     * database 数据库对象
     */
    data: Record<string,string>&{value:string}
    msg: string
  }> {
    return new Promise((resolve, reject) => {
      if (!the_dataBase) {
        reject('数据库不存在或没有初始化')
      }
      const req = the_dataBase!
        .transaction([the_storeName], 'readonly')
        .objectStore(the_storeName) // 仓库对象
        .get(key)
      // 操作成功
      req.onsuccess = function (e: { target: { result: any } }) {
        resolve({
          code: 0,
          success: true,
          data: e?.target?.result,
          msg: '数据获取成功!',
        })
      }
      // 操作失败
      req.onerror = function () {
        const data = {
          code: -1,
          success: false,
          data: null,
          msg: '数据获取失败!',
        }
        resolve(data)
      }
    })
  }

  /**
   * 删除数据
 
   * @param {string} key 数据主键
   **/
  const deleteData = function (key: string) {
    return new Promise((resolve, reject) => {
      if (!the_dataBase) {
        reject('数据库不存在或没有初始化')
      }
      const req = the_dataBase!
        .transaction([the_storeName], 'readwrite')
        .objectStore(the_storeName) // 仓库对象
        .delete(key)
      // 操作成功
      req.onsuccess = function (e: { target: { result: any } }) {
        resolve({
          code: 0,
          success: true,
          data: e?.target?.result,
          msg: '数据删除成功!',
        })
      }
      // 操作失败
      req.onerror = function () {
        const data = {
          code: -1,
          success: false,
          data: null,
          msg: '数据删除失败!',
        }
        resolve(data)
      }
    })
  }

  /**
   * 使用游标查询数据
   * @param {string} indexKey 查询的索引的键值
   * @param {string} index 查询的索引值
   **/
  const getIndexData = function (indexKey: string, index: string) {
    return new Promise((resolve, reject) => {
      if (!the_dataBase) {
        reject('数据库不存在或没有初始化')
      }
      const keyRange = IDBKeyRange.only(index)
      const req = the_dataBase!
        .transaction([the_storeName], 'readonly')
        .objectStore(the_storeName) // 仓库对象
        .index(indexKey)
        .openCursor(keyRange, 'next')
      // 操作成功
      req.onsuccess = function (e: { target: { result: any } }) {
        resolve({
          code: 0,
          success: true,
          data: e?.target?.result,
          msg: '数据查询成功!',
        })
      }
      // 操作失败
      req.onerror = function () {
        const data = {
          code: -1,
          success: false,
          data: null,
          msg: '数据查询失败!',
        }
        resolve(data)
      }
    })
  }
  return { openDB, addData, updateData, getData, deleteData, getIndexData }
}
