/*
 * @Author: error: git config user.name & please set dead value or install git
 * @Date: 2023-06-18 16:20:20
 * @Description: 全局初始化
 */
import { getAction } from "@/api/manage";
import {
  useSystemPinia,
  useSystemStoreWithOut,
} from "@/pinia/modules/systemPinia";
import { useUserPiniaWithOut } from "@/pinia/modules/userPinia";
import { useWatermark } from "./useWatermark";
import {
  useCategoryPinia,
  useCategoryPiniaWithOut,
} from "@/pinia/modules/categoryPinia";

/**
 * 全局初始化
 */
export function setupGlobalInit() {
  // const themePinia = useThemePinia();

  // themePinia.init();

  //如果已经登录了就有这个信息
  if (useUserPiniaWithOut().judgeLogin()) {
    useInitAfterLogin();
  }
}
/**
 * 登录后初始化系统
 */
export function useInitAfterLogin() {
  useUserPiniaWithOut().getLocation();
  // useThemeStoreWithOut().changeWatermark(false);
  useSystemStoreWithOut().init();
  useCategoryPiniaWithOut().init();
}
