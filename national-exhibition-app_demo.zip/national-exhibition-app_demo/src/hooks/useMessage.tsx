import { useToast } from "nutui-uniapp/components/composables";
/**
 * ant message
 * @returns
 */
export function useMessage() {
  return {
    /**消息 */
    createMessage: useToast(),
    /**
     * 消息盒子
     */
    // createModal: Modal,
    /**
     * 通知提示
     */
    // createNotification: notification,
  };
}
