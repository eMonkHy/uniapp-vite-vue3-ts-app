/*
 * @Author: zhangwei
 * @Date: 2023-04-24 20:13:05
 * @Description:N
 */
import { NsSystem } from "#/system";
import { ref, onMounted, onUnmounted } from "vue";
import { VueJsonp, jsonp } from "vue-jsonp";

/**
 * @description 用户网络是否可用
 * */
export function useOnline() {
  const online = ref(true);

  const showStatus = (val) => {
    online.value = typeof val == "boolean" ? val : val.target.online;
  };

  // 在页面加载后，设置正确的网络状态
  navigator.onLine ? showStatus(true) : showStatus(false);

  onMounted(() => {
    // #ifdef APP-PLUS
    uni.onNetworkStatusChange(function (res) {
      showStatus(res.isConnected);
    });
    // #endif
    // 开始监听网络状态的变化
    // #ifdef H5
    window.addEventListener("online", showStatus);

    window.addEventListener("offline", showStatus);
    // #endif
  });
  onUnmounted(() => {
    // #ifdef APP-PLUS
    uni.offNetworkStatusChange(function (res) {
      showStatus(res.isConnected);
    });
    // #endif
    // 移除监听网络状态的变化
    // #ifdef H5
    window.removeEventListener("online", showStatus);

    window.removeEventListener("offline", showStatus);
    // #endif
  });

  return { online };
}
/**
 * 获取定位
 */
export async function getLocationByIp(): Promise<NsSystem.txLocation> {
  var data: any = {
    key: "JFWBZ-43WWO-3RPWI-SEM6H-BIQF6-2UBCR", //密钥
  };
  var url = "https://apis.map.qq.com/ws/location/v1/ip"; //腾讯地理位置信息接口
  data.output = "jsonp"; // 解决跨域问题
  let r_result: any;
  await jsonp(url, data)
    .then((res) => {
      r_result = res;
    })
    .catch((error) => {});

  return r_result;
}

export async function getTodayWeather(
  a_location: NsSystem.txLocation,
  a_extensions: NsSystem.gdWeatherParams["extensions"] = "base"
): Promise<NsSystem.gdWeather> {
  let url = "https://restapi.amap.com/v3/weather/weatherInfo";
  let data: NsSystem.gdWeatherParams = {
    key: "69b52e72f8500eacec7016fb3379294b",
    city: a_location.result.ad_info.adcode,
    output: "JSON",
    extensions: a_extensions,
  };
  let r_result: any;
  await jsonp(url, data)
    .then((res) => {
      r_result = res;
    })
    .catch((error) => {});
  return r_result;
}
