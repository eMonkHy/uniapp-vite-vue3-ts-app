//引入ant design vue的css 白色和黑色的less文件都要引入
import { useThemeStoreWithOut } from '@/pinia/modules/themePinia'
import { toggleClass } from '@/utils/domUtils';
 

/**
 * 获取主题前缀
 */
export function  getThemePrefixCls(){


 return useThemeStoreWithOut().themeMode;

}
/**
 * 更新色弱模式
 * @param colorWeak
 */
export function updateColorWeak(colorWeak: boolean) {
  toggleClass(colorWeak, 'color-weak', document.documentElement);
}
/**
 * 更新灰度
 * @param gray
 */
export function updateGrayMode(gray: boolean) {
  toggleClass(gray, 'gray-mode', document.documentElement);
}
