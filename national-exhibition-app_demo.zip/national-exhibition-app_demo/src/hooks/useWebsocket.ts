type DataType = {
  loadding: boolean;
  url: {
    listCementByUser: string;
    editCementSend: string;
    queryById: string;
  };
  hovered: false;
  announcement1: Annouce[];
  announcement2: Annouce[];
  msg1Count: string;
  msg2Count: string;
  msg1Title: string;
  msg2Title: string;
  stopTimer: boolean;
  websock: any;
  lockReconnect: boolean;
  heartCheck?: {
    /**定时器重连 */
    interValReconect: undefined;
    timeout: number;
    timeoutObj: null;
    serverTimeoutObj: null;
    reset: Function;
    start: Function;
  };
  formData: {};
  openPath: "";
};

let data = reactive<DataType>({
  loadding: false,
  url: {
    listCementByUser: "/sys/annountCement/listByUser",
    editCementSend: "/sys/sysAnnouncementSend/editByAnntIdAndUserId",
    queryById: "/sys/annountCement/queryById",
  },
  hovered: false,
  announcement1: [],
  announcement2: [],
  msg1Count: "0",
  msg2Count: "0",
  msg1Title: "通知(0)",
  msg2Title: "",
  stopTimer: false,
  websock: null,
  lockReconnect: false,
  formData: {},
  openPath: "",
});
// 初始化websocket
export default (arg_userId:string) => {
  // WebSocket与普通的请求所用协议有所不同，ws等同于http，wss等同于https
  let userId = arg_userId;
  console.log(
    "%c [ userId ]-66",
    "font-size:13px; background:#6b75eb; color:#afb9ff;",
    userId
  );
  var url =
    getApp()._CONFIG["domianURL"]
      .replace("https://", "wss://")
      .replace("http://", "ws://") +
    "/websocket/" +
    userId;
  console.log(
    "%c [ url ]-68",
    "font-size:13px; background:#10d604; color:#54ff48;",
    url
  );
  data.websock = new WebSocket(url);
  data.websock.onopen = websocketOnopen;
  data.websock.onerror = websocketOnerror;
  data.websock.onmessage = websocketOnmessage;
  data.websock.onclose = websocketOnclose;
};

function websocketOnopen() {
  console.log("websoket连接成功");
}
function websocketOnerror(e) {
  console.log("WebSocket连接发生错误");
}
function websocketOnmessage(e) {
  console.log("接收消息", e.data);
}
function websocketOnclose(e) {
  console.log("connection closed(" + e + ")");
}
