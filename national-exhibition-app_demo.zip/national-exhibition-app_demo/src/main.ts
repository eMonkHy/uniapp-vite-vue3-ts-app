import { createSSRApp } from "vue";
import App from "./App.vue";
import { getAppEnvConfig } from "./utils/env";
import { mockXHR } from "./mock";
import { setupStore } from "./pinia";
import { setupDirectives } from "./directives";
import { setupGlobalInit } from "./hooks/useInit";
import { setupGlobalProperties } from "./hooks/useGlobalProperties";
export function createApp() {
  const app = createSSRApp(App);

  // 配置存储pinia
  setupStore(app);

  // 注册全局自定义指令，如：v-permission权限指令
  setupDirectives(app);
  // 路由保护
  // setupRouterGuard(router);
  //自定义组件
  // setupGlobComp(app);

  // 当路由准备好时再执行挂载( https://next.router.vuejs.org/api/#isready)
  // await router.isReady()
  setupGlobalProperties(app);
  setupGlobalInit();

  return {
    app,
  };
}
