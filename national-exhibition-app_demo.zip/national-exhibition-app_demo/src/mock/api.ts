import axios from "axios"
// mock测试接口-存储token
function postToken(config: { page: any; }) {
    const params = new URLSearchParams()
    params.append('page', config.page as string)

    return axios({
        url: "/auth/oauth/token",
        method:"post",
        data: params
    })
}
// mock测试接口-获取随机用户信息
function getRandomData() {
    return axios({
        url: "/user/userInfo",
        method:"get",
    })
}

export {postToken,getRandomData}
