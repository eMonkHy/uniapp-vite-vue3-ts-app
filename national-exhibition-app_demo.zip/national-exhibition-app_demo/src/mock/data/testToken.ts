
import Mock from "mockjs";
export default [
  // GetUserInfo
  {
    url: "/upms/user/info",
    type: "get",
    response: () => {
      return {
        code: 200,
        message: "成功",
        data: {
          name: "testName",
        },
      };
    },
  },
  // GetToken
  {
    url: "/auth/oauth/token",
    type: "post",
    response: (option: any) => {
        return Mock.mock({
          code: 200,
          message: "成功",
          data: {
            token: "testToken123qwer456asd",
          },
        });
      }
    },
]
