import Mock from "mockjs";

export function ProjectInfoList() {
  // return Mock.mock({
  //   index:"@"
  // })
}
