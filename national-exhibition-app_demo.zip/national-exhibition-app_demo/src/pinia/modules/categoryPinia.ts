/*
 * @Author: 张伟
 * @Date: 2023-05-09 17:25:38
 * @Description: 分类字典
 */
import { defineStore } from "pinia"
import { store } from ".."
import { TreeSelectModel, 分类字典Service } from "@/api/services/systemService"
import { ande_const } from "@/config/global_const"
import { getSysConfig } from "@/utils/zw"

interface categoryPinia {
  /**
   * 默认用到的list
   */
  categoryCodeList: string[]

  /* 正在分类加载的list */
  cateLoadingList: string[]
  /* 分类list */
  categoryTreeModelList?: {
    code: string
    id?: string
    nodeList: TreeSelectModel[]
  }[]
}
export const useCategoryPinia = defineStore({
  id: "useCategoryPinia",
  state: (): categoryPinia => ({
    categoryCodeList: [],
    categoryTreeModelList: [],

    cateLoadingList: [],
  }),
  getters: {},
  actions: {
    init() {
      this.categoryCodeList.push(getSysConfig(ande_const.activiti.分类字典)!)
      this.categoryCodeList.forEach((v_code) => {
        分类字典Service.loadOnlyCateGoryTreeData({ code: v_code }).then((res) => {
          if (res.success) {
            this.categoryTreeModelList?.push({
              code: v_code,
              nodeList: res.result,
            })
            // let dictTreenode = res.result.find((v_key) => v_key.key == a_key);
          }
        })
      })
    },

    getCateText(a_key: any, a_code?: string) {
      let r_text: string | undefined = ""
      if (a_code) {
        let cateList = this.categoryTreeModelList?.find((v_treeList) => v_treeList.code == a_code)
        r_text = cateList?.nodeList.find((v_cate) => v_cate.key == a_key)?.title
      } else {
        this.categoryTreeModelList?.forEach((v_list) => {
          r_text = v_list?.nodeList.find((v_cate) => v_cate.key == a_key)?.title
        })
      }
      return r_text
    },
    /**
     * 根据父级code获取子集id
     */
    getCateIdByPCode(a_code?: string, a_pCode?: string) {
      let r_key: string | undefined = ""

      if (!!a_pCode) {
        let cateList = this.categoryTreeModelList?.find((v_treeList) => v_treeList.code == a_pCode)
        r_key = cateList?.nodeList.find((v_cate) => v_cate.code == a_code)?.key
      }
      return r_key
    },
  }, //持久化
})
/**
 * 提供给外部使用 【提供给外部使用pinia】
 */
export function useCategoryPiniaWithOut() {
  return useCategoryPinia(store)
}
