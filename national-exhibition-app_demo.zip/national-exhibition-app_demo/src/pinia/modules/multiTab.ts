import { defineStore } from "pinia";

interface MultiTabPinia {
  activeKey: string | number | undefined;
  multTab: any[];
  fullPath: string[];
  hoverKey?: number;
}

export const useMultiTab = defineStore({
  id: "multiTabPinia",
  state: ():MultiTabPinia => ({
    activeKey: undefined,
    multTab: [],
    fullPath: [],
    hoverKey: undefined,
  }),
});
