/**
 * pinia状态存储
 */
import { defineStore } from "pinia";

import {
  DictModel,
  IPage_SysConfig,
  LoginBo,
  SysConfig,
  SysLoginModel,
  SysUser,
  参数配置Service,
  用户登录Service,
} from "@/api/services/systemService";
import { getAuthCache, setAuthCache } from "@/utils/auth";
import {
  DB_DICT_DATA_KEY,
  IS_LOCKSCREEN,
  TENANT_ID,
  TOKEN_KEY,
} from "@/enums/cacheEnum";
import { NsPermissions, NsSystem } from "#/system";
import { store } from "..";
import WebStorage from "@/utils/cache";
import { Persistent } from "@/utils/cache/persistent";
import { useMessage } from "@/hooks/useMessage";
import { getAction } from "@/api/manage";
import { getAppEnvConfig } from "@/utils/env";
const { createMessage} = useMessage();

// 长时间不操作默认锁屏时间
const initTime = 60 * 60;
const isLock = Persistent.getLocal<boolean>(IS_LOCKSCREEN);
interface SystemPinia {
  dictItemList?: NsSystem.dictItemsList;
  /**是否锁屏 */
  isLock: boolean;
  /**锁屏时间 */
  lockTime: number;
  /**当前激活顶部菜单key */
  activeTopMenuKey?: string;
  /**系统参数配置 */
  sysConfigList?: SysConfig[];
}
// defineStore 调用后返回一个函数，调用该函数获得Store实体
export const useSystemPinia = defineStore({
  id: "systemPinia",
  //state: 返回对象的函数
  state: (): SystemPinia => ({
    isLock: isLock === true, // 是否锁屏
    lockTime: isLock ? initTime : 0,
    activeTopMenuKey: "",
    sysConfigList: undefined,
  }),
  getters: {},
  actions: {
    /**
     * 初始化
     */
    init() {
        this.loadSysConfg();
    },
    /**
     * 加载系统 参数配置
     */
    loadSysConfg() {
      getAction<SysConfig[]>("/sys/api/getSysConfigList", {
        pageSize: 9999,
      }).then((res) => {
        if (res.success) {
          this.sysConfigList = res.result;
        } else {
          createMessage.error(res.message);
        }
      });
    },

    /**
     * 更新参数配置
     * @param a_config 参数
     */
    updateSysConfig(a_config: SysConfig) {
      if (this.sysConfigList) {
        let configIndex = this.sysConfigList?.findIndex((v_config) => {
          return v_config.configKey == a_config.configKey;
        });
        if (configIndex != -1) {
          //更新
          this.sysConfigList[configIndex] = a_config;
        } else {
          //新增
          this.sysConfigList?.push(a_config);
        }
      }
    },
    /**
     * 设置锁屏
     * @param isLock 是否锁屏
     */
    setLock(isLock: boolean) {
      this.isLock = isLock;
      //@ts-ignore
      Persistent.setLocal(IS_LOCKSCREEN, this.isLock);
    },
    /**
     * 设置锁屏时间
     * @param lockTime 锁屏时间
     */
    setLockTime(lockTime: number = initTime) {
      this.lockTime = lockTime;
    },
    /**
     * 设置字典项目list
     * @param a_dictItems 字典项目list
     */
    setDictItems(a_dictItems: NsSystem.dictItemsList) {
      setAuthCache(DB_DICT_DATA_KEY, a_dictItems);
    },
    clearDictItems() {
      setAuthCache(DB_DICT_DATA_KEY, undefined);
    },

    /**
     * 改变顶部导航key
     * @param a_key 顶部导航key
     */
    changeTopMenuKey(a_key: string) {
      console.log(
        "%c [ a_key ]-81",
        "font-size:13px; background:#f8a3c4; color:#ffe7ff;",
        a_key
      );
      this.activeTopMenuKey = a_key;
    },
  },
  //持久化
  persist: {
    enabled: true,
    strategies: [
      {
        key: getAppEnvConfig().VITE_GLOB_APP_SHORT_NAME+"systemPinia",
        storage: localStorage,
      },
    ],
  },
});

// Need to be used outside the setup
export function useSystemStoreWithOut() {
  // return useThemeStore(store);
  return useSystemPinia(store);
}
