import { EnumTaskFullScreenMode } from "@/enums";
import { reject } from "lodash";
import { resolve } from "path";
import { defineStore } from "pinia";

interface optionsType {
  value: string;
  label: string;
  children?: optionsType[];
}
/**
 * 任务看板
 */
export const useTaskKanbanPinia = defineStore("TaskKanbanPinia", {
  state: () => {
    return {
      /**
       * 全屏模式
       */
      fullScreenMode: EnumTaskFullScreenMode.无 as EnumTaskFullScreenMode,
    };
  },
  persist: {
    enabled: true,
    strategies: [
      {
        paths: ["fullScreenMode"],
      },
    ],
  },

  actions: {
    /**
     * 改变全屏模式
     * @param fullScreenMode 全屏模式
     */
    changeFullScreeMode(fullScreenMode: EnumTaskFullScreenMode) {
      this.fullScreenMode = fullScreenMode;
    },
    /**
     * 重置
     */
    resetFullSccreeMode() {
      this.fullScreenMode = EnumTaskFullScreenMode.无;
    },
  },
});
