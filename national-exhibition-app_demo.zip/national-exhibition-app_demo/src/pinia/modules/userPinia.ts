/**
 * pinia状态存储
 */
import { defineStore } from "pinia";
import { createPinia } from "pinia";
import piniaPersist from "pinia-plugin-persist";
import { store } from "..";

import {
  DictModel,
  LoginBo,
  SysLoginModel,
  SysUser,
  接口返回对象,
  用户登录Service,
  用户表Service,
  JSONObject,
  SysDepart,
} from "@/api/services/systemService";
import { getAuthCache, setAuthCache } from "@/utils/auth";
import {
  CUR_USER_DEPART_ID,
  CUR_USER_DEPART_NAME,
  CUR_USER_DEPART_SERVICE,
  DB_DICT_DATA_KEY,
  TENANT_ID,
  TOKEN_KEY,
  USER_NAME,
} from "@/enums/cacheEnum";

import { NsPermissions, NsSystem } from "#/system";
import { useSystemPinia } from "./systemPinia";
import { getLocationByIp } from "@/hooks/useOnline";
import { useMessage } from "@/hooks/useMessage";
import { getAppEnvConfig, isMockMode } from "@/utils/env";
import { mock_userList } from "@/mock/data/mock_userList";
import { buildUUID } from "@/utils/uuid";
import { useInitAfterLogin } from "@/hooks/useInit";
import { RouteRecordRaw } from "vue-router";
import { EnumPage } from "@/enums";
import { isMobile } from "@/utils/zw";
const { createMessage, createModal, createNotification } = useMessage();

interface UserPinia {
  token?: string;
  tenantId?: string;
  testToken: string;
  userInfo?: SysUser;

  location?: NsSystem.txLocation;
  logOutLoading: boolean;
  /**所属部门 */
  departments: SysDepart[];
  /**所属部门ids */
  departmentIds: string[];

  /**登录选择的部门 */
  loginChooseDepart?: SysDepart;
}
type RegisterModalType = NonNullable<
  Parameters<(typeof 用户表Service)["register"]>
>[0];

// defineStore 调用后返回一个函数，调用该函数获得Store实体
export const useUserPinia = defineStore({
  id: "userPinia",
  //state: 返回对象的函数
  state: (): UserPinia => ({
    token: "",
    userInfo: undefined,
    testToken: "",
    location: undefined,
    tenantId: undefined,
    logOutLoading: false,
    departments: [],
    departmentIds: [],
    loginChooseDepart: undefined,
  }),
  getters: {
    /**获取token */
    getToken(): string | undefined {
      return getAuthCache(TOKEN_KEY) || this.token;
    },
    /**获取企业租户id */
    getTenantId(): number {
      return Number(this.tenantId);
    },
    getCurUserDepart(): {
      id?: string;
      departName?: string;
      ifService?: boolean;
    } {
      return {
        id: this.loginChooseDepart?.id || getAuthCache(CUR_USER_DEPART_ID),
        departName:
          this.loginChooseDepart?.departName ||
          getAuthCache(CUR_USER_DEPART_NAME),
        ifService:
          (this.loginChooseDepart?.ifService ||
          getAuthCache(CUR_USER_DEPART_SERVICE)) == 1,
      };
    },
  },
  actions: {
    /**
     * 判断是否已经登录【重要】
     */
    judgeLogin() {
      return Boolean(this.token);
    },
    /**
     * 修改用户信息
     * @param a_SysUser 用户信息
     */
    updateUserInfo(a_SysUser: SysUser) {
      console.log(
        "%c [ a_SysUser ]-94",
        "font-size:13px; background:#a8bd8d; color:#ecffd1;",
        a_SysUser
      );
      this.userInfo = a_SysUser;
    },
    /**
     * 获取位置
     */
    async getLocation(a_needMsg: boolean = false) {
      let location = await getLocationByIp();
      if (a_needMsg) {
        if (location.status == 0) {
          createMessage.success("获取定位成功");
        } else {
          createMessage.error(`获取定位失败 ${location.message}`);
        }
      }
      this.location = location;
    },

    /* 注册 */
    register(
      a_regiterParams: RegisterModalType
    ): Promise<接口返回对象<JSONObject>> {
      return 用户表Service.register(a_regiterParams);
    },

    /**登录 */
    async login(
      a_loginParams: SysLoginModel
    ): Promise<接口返回对象<LoginBo> | void> {
      let r_LoginBo: LoginBo | undefined = undefined;
      let that = this;

      if (isMockMode()) {
        let r_data: 接口返回对象<LoginBo> = {
          code: 200,
          message: "成功",
          success: true,
          result: {},
        };
        return new Promise(function (resolve, reject) {
          let findUser = mock_userList.find((v_user) => {
            return v_user.username == a_loginParams.username;
          });
          if (findUser) {
            r_data.success = true;
          } else {
            r_data.success = false;
            r_data.message = "用户名不正确";
          }
          getLocationByIp();
          that.userInfo = findUser;

          that.setToken(buildUUID());
          resolve(r_data);
        });
      } else {
        //正式环境
        return await 用户登录Service
          .login({
            sysLoginModel: a_loginParams,
          })
          .then(async (res) => {
            if (res.success) {
              // message.success(res.message);
              this.userInfo = res.result.userInfo;
              this.departments = res.result.departs || [];
              this.departmentIds = (res.result.departs || []).map(
                (item) => item.id!
              );
              setAuthCache(USER_NAME, this.userInfo?.username);

              useSystemPinia().setDictItems(
                res.result.sysAllDictItems as NsSystem.dictItemsList
              );

              this.setTenantId(res.result.userInfo?.relTenantIds);
              this.setToken(res.result.token);

              // const permissionPinia = usePermissionPinia();
              // if (
              //   !permissionPinia.menuItemList ||
              //   permissionPinia.menuItemList?.length == 0
              // ) {
              //   await usePermissionPiniaWithOut().initData();
              //   usePermissionPiniaWithOut()
              //     .getMenuList()
              //     ?.forEach((v_menu) => {
              //       router.addRoute(v_menu as unknown as RouteRecordRaw);
              //     });
              // }
              r_LoginBo = res.result;

              useInitAfterLogin();
            } else {
              // message.error(res.message);
            }
            return res;
          })
          .finally(() => {});
      }
    },
    loginSuccess() {
      console.log(
        "%c [ loginSuccess ]-213",
        "font-size:13px; background:#05c84b; color:#49ff8f;"
      );
      if (isMobile()) {
        // router.replace(EnumPage.APP_INDEX_MAIN_PAGE_PATH);
        // router.push({ path: EnumPage.APP_INDEX_MAIN_PAGE_PATH });
      } else {
        // const redirectQuery = router.currentRoute.value.query;
        // console.log(
        //   "%c [ redirectQuery ]-212",
        //   "font-size:13px; background:#fcf19f; color:#ffffe3;",
        //   redirectQuery
        // );
        // if (
        //   !!redirectQuery &&
        //   redirectQuery.redirect &&
        //   typeof redirectQuery.redirect == "string"
        // ) {
        //   router.replace(redirectQuery.redirect);

        //   // router.push({ path: redirectQuery.redirect });
        // } else {
        //   const n_path = router.currentRoute.value.path;
        //   if (!!n_path) {
        //     router.replace(n_path);
        //     // router.push({ path: n_path });
        //   } else {
        //     // router.push({ path: EnumPage.INDEX_MAIN_PAGE_PATH });
        //     router.replace(EnumPage.INDEX_MAIN_PAGE_PATH);
        //   }
        // }
      }
    },
    /**退出 */
    async logOut() {
      this.logOutLoading = true;
      // usePermissionPinia().clearData();

      this.userInfo = undefined;
      this.token = undefined;
      this.loginChooseDepart = undefined;

      setAuthCache(TOKEN_KEY, undefined);
      setAuthCache(TENANT_ID, undefined);

      setAuthCache(DB_DICT_DATA_KEY, undefined);
      setAuthCache(CUR_USER_DEPART_ID, undefined);
      setAuthCache(CUR_USER_DEPART_NAME, undefined);
      setAuthCache(CUR_USER_DEPART_SERVICE, undefined);

      await setTimeout(() => {
        this.logOutLoading = false;
      }, 1000);
    },
    /**
     * 设置字典项目list
     * @param a_dictItems 字典项目list
     */
    setDictItems(a_dictItems: NsSystem.dictItemsList) {
      setAuthCache(DB_DICT_DATA_KEY, a_dictItems);
    },
    /**
     * 设置企业租户id
     * @param a_tenantId token
     */
    setTenantId(a_tenantId?: string) {
      if (!a_tenantId) return;
      this.tenantId = a_tenantId;
      setAuthCache(TENANT_ID, a_tenantId);
    },
    setCurDepart(a_sysDepart?: SysDepart) {
      console.log(
        "%c [ a_sysDepart ]-284",
        "font-size:13px; background:#3416a7; color:#785aeb;",
        a_sysDepart
      );
      if (!a_sysDepart) {
        return;
      }
      this.loginChooseDepart = a_sysDepart;
      setAuthCache(CUR_USER_DEPART_ID, a_sysDepart.id);
      setAuthCache(CUR_USER_DEPART_NAME, a_sysDepart.departName);
      setAuthCache(CUR_USER_DEPART_SERVICE, a_sysDepart.ifService);
    },

    /**
     * 设置登陆token
     * @param a_token token
     */
    setToken(a_token?: string) {
      this.token = a_token;
      setAuthCache(TOKEN_KEY, a_token);
    },
    /**
     * 设置userInfo
     * @param a_userInfo
     */
    setUserInfo(a_userInfo?: SysUser) {
      if (!a_userInfo) return;
      this.userInfo = a_userInfo;
    },

    // async postToken() {
    //   const getToken = await postToken({ page: '1' })
    //   this.token = getToken.data.data.token
    // },

    // async getRandomData() {
    //   const randomData = await getRandomData()
    // },
  },
  //持久化
  persist: {
    enabled: true,
    strategies: [
      {
        key: getAppEnvConfig().VITE_GLOB_APP_SHORT_NAME + "userPinia",
        storage: localStorage,
        paths: [
          "userInfo",
          "location",
          "token",
          "departmentIds",
          "departments",
          "loginChooseDepart",
        ],
      },
    ],
  },
});

const pinia = createPinia();
pinia.use(piniaPersist);

export default pinia;

function getCarList(arg0: { page: number }) {
  throw new Error("Function not implemented.");
}
/**
 * 提供给外部使用 【提供给外部使用pinia】
 */
export function useUserPiniaWithOut() {
  return useUserPinia(store);
}
