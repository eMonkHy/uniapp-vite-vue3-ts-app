import { NsAndeWebsocket } from '#/system'
import { defineStore } from 'pinia'

 
/**
 * 消息通知pinia
 */
export const useWebsocketPinia = defineStore('websocketPinia', {
  state: () => {
    return {
      
    }
  },

  actions: {
    receiveMessages(a_data: NsAndeWebsocket.WebsocketHandleData) {
      console.log('%c [ a_data ]-15', 'font-size:13px; background:#99adf6; color:#ddf1ff;', a_data)
    },
  },
})
