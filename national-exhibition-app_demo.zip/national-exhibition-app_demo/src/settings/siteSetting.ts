export const GITHUB_URL = 'https://github.com/doc/doc-vue3';

export const DOC_URL = 'http://vue3.doc.com';

export const SITE_URL = 'http://www.doc.com';
