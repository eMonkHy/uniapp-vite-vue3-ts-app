import type { LockInfo, UserInfo, LoginInfo } from "#/store";
import type { ProjectConfig } from "#/config";
import type { RouteLocationNormalized } from "vue-router";

import { createLocalStorage, createSessionStorage } from "@/utils/cache";
import { Memory } from "./memory";
import {
  TOKEN_KEY,
  USER_INFO_KEY,
  USER_NAME,
  ROLES_KEY,
  LOCK_INFO_KEY,
  PROJ_CFG_KEY,
  APP_LOCAL_CACHE_KEY,
  APP_SESSION_CACHE_KEY,
  MULTIPLE_TABS_KEY,
  DB_DICT_DATA_KEY,
  TENANT_ID,
  LOGIN_INFO_KEY,
  CACHE_INCLUDED_ROUTES,
  CACHE_MENU_RESULT,
  CACHE_MENU_HISTORY,
  CUR_USER_DEPART_ID,
  CUR_USER_DEPART_NAME,
  CUR_USER_DEPART_SERVICE
} from "@/enums/cacheEnum";
import { DEFAULT_CACHE_TIME } from "@/settings/encryptionSetting";
import { toRaw } from "vue";
import { pick, omit } from "lodash-es";
import { AndeMenuItemType, NsPermissions } from "#/system";

interface BasicStore {
  [TOKEN_KEY]: string | number | null | undefined;
  [USER_INFO_KEY]: UserInfo;
  /**登录用户账号 */
  [USER_NAME]: string;
  [ROLES_KEY]: string[];
  [LOCK_INFO_KEY]: LockInfo;
  [PROJ_CFG_KEY]: ProjectConfig;
  [MULTIPLE_TABS_KEY]: RouteLocationNormalized[];
  [DB_DICT_DATA_KEY]: string;
  [TENANT_ID]: string;
  [LOGIN_INFO_KEY]: LoginInfo;
  IS_LOCKSCREEN: string;
  DEMO: String;
  [CACHE_INCLUDED_ROUTES]: string[];
  [CACHE_MENU_RESULT]: string[];
  [CACHE_MENU_HISTORY]: NsPermissions.PermissionReturnData[];
  [CUR_USER_DEPART_ID]: string;
  [CUR_USER_DEPART_NAME]: string;
  [CUR_USER_DEPART_SERVICE]: number;
}

type LocalStore = BasicStore;

type SessionStore = BasicStore;

export type BasicKeys = keyof BasicStore;
type LocalKeys = keyof LocalStore;
type SessionKeys = keyof SessionStore;

const ls = createLocalStorage();
const ss = createSessionStorage();

const localMemory = new Memory(DEFAULT_CACHE_TIME);
const sessionMemory = new Memory(DEFAULT_CACHE_TIME);

function initPersistentMemory() {
  console.log(
    "%c [ 初始化memory ]-52",
    "font-size:13px; background:#4710a4; color:#8b54e8;"
  );
  const localCache = ls.get(APP_LOCAL_CACHE_KEY);
  const sessionCache = ss.get(APP_SESSION_CACHE_KEY);
  localCache && localMemory.resetCache(localCache);
  sessionCache && sessionMemory.resetCache(sessionCache);
}

export class Persistent {
  /**
   * memoryValue 全局变量
   * @param key
   */
  static getLocal<T>(key: LocalKeys) {
    let memoryValue = localMemory.get(key);
    if (memoryValue && memoryValue.value) {
      return memoryValue.value as NonNullable<T>;
    }
    return undefined;
  }

  static setLocal(
    key: LocalKeys,
    value: LocalStore[LocalKeys],
    immediate = false
  ): void {
    localMemory.set(key, toRaw(value));
    immediate && ls.set(APP_LOCAL_CACHE_KEY, localMemory.getCache);
  }

  static removeLocal(key: LocalKeys, immediate = false): void {
    localMemory.remove(key);
    immediate && ls.set(APP_LOCAL_CACHE_KEY, localMemory.getCache);
  }

  static clearLocal(immediate = false): void {
    localMemory.clear();
    immediate && ls.clear();
  }

  static getSession<T>(key: SessionKeys) {
    return sessionMemory.get(key)?.value as Nullable<T>;
  }

  static setSession(
    key: SessionKeys,
    value: SessionStore[SessionKeys],
    immediate = false
  ): void {
    sessionMemory.set(key, toRaw(value));
    immediate && ss.set(APP_SESSION_CACHE_KEY, sessionMemory.getCache);
  }

  static removeSession(key: SessionKeys, immediate = false): void {
    sessionMemory.remove(key);
    immediate && ss.set(APP_SESSION_CACHE_KEY, sessionMemory.getCache);
  }
  static clearSession(immediate = false): void {
    sessionMemory.clear();
    immediate && ss.clear();
  }

  static clearAll(immediate = false) {
    sessionMemory.clear();
    localMemory.clear();
    if (immediate) {
      ls.clear();
      ss.clear();
    }
  }
}

window.addEventListener("beforeunload", function () {
  // TOKEN_KEY 在登录或注销时已经写入到storage了，此处为了解决同时打开多个窗口时token不同步的问题
  // LOCK_INFO_KEY 在锁屏和解锁时写入，此处也不应修改
  ls.set(APP_LOCAL_CACHE_KEY, {
    ...omit(localMemory.getCache, LOCK_INFO_KEY),
    ...pick(ls.get(APP_LOCAL_CACHE_KEY), [
      TOKEN_KEY,
      USER_INFO_KEY,
      LOCK_INFO_KEY,
    ]),
  });
  ss.set(APP_SESSION_CACHE_KEY, {
    ...omit(sessionMemory.getCache, LOCK_INFO_KEY),
    ...pick(ss.get(APP_SESSION_CACHE_KEY), [
      TOKEN_KEY,
      USER_INFO_KEY,
      LOCK_INFO_KEY,
    ]),
  });
});

function storageChange(e: any) {
  const { key, newValue, oldValue } = e;

  if (!key) {
    Persistent.clearAll();
    return;
  }

  if (!!newValue && !!oldValue) {
    if (APP_LOCAL_CACHE_KEY === key) {
      Persistent.clearLocal();
    }
    if (APP_SESSION_CACHE_KEY === key) {
      Persistent.clearSession();
    }
  }
}

window.addEventListener("storage", storageChange);

initPersistentMemory();
