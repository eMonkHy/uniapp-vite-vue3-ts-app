export function reloadPage() {
  const pages = getCurrentPages();
  const curPage = pages[pages.length - 1];
  console.log('%c [ curPage ]-4', 'font-size:13px; background:#88a518; color:#cce95c;', curPage)
  if (!!curPage && !!curPage.onLoad) {
    curPage.onLoad();
  }
}
