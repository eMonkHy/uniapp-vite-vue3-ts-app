

import { App } from "vue";
import service from "@/api/request";
import { isJsonObjectString, isObject } from "./is";
import { AndeMenuItemType, NsSystem } from "#/system";
import {
  ChatGroup,
  SysUser,
  TreeSelectModel,
} from "@/api/services/systemService";
import { useMessage } from "@/hooks/useMessage";
import { useSystemStoreWithOut } from "@/pinia/modules/systemPinia";
import { getAppEnvConfig } from "./env";
import { ande_const } from "@/config/global_const";
import { getAuthCache } from "./auth";
import { TOKEN_KEY } from "@/enums";

/**
 * 类型转化
 * @param obj 实体
 */
export function convert<T>(obj: any) {
  return obj as T;
}

const { createMessage} = useMessage();
/**
 * 简单实现防抖方法
 *
 * 防抖(debounce)函数在第一次触发给定的函数时，不立即执行函数，而是给出一个期限值(delay)，比如100ms。
 * 如果100ms内再次执行函数，就重新开始计时，直到计时结束后再真正执行函数。
 * 这样做的好处是如果短时间内大量触发同一事件，只会执行一次函数。
 *
 * @param fn 要防抖的函数
 * @param delay 防抖的毫秒数
 * @returns {Function}
 */
export function simpleDebounce(fn, delay = 100) {
  let timer = null;
  return function () {
    let args = arguments;
    if (timer) {
      clearTimeout(timer);
    }
    timer = setTimeout(() => {
      fn.apply(this, args);
    }, delay);
  };
}
/**随机获取一句话
 * @method getQuote
 * @return {String}
 */
export function getQuote() {
  var quoteArr = [
    "专注、热爱、 全心贯注于你望的事物上，必有收获。",
    "成大事不在于力量的大小，而在于能坚持多久",
    "如果你比对手更专注，你就能把他抛在身后。",
    "每天早晨醒来，一想到所从事的工作和所开发的技术将会给人类生活带来巨大的影响和变化，我就会无比兴奋和激动。",
    "生活往往就是这样。匆匆忙忙，匆忙中失去了自己，为的只是不停地向前，不停地自我延伸。为了不断求新，许多事情在被遗忘。——塞弗尔特",
    "任何人都是这样，处理别人的事情总是大刀阔斧一把抓住主要问题，轮到自己却沉浸在细枝末节不肯放手。——八月长安",
    "这世上真正能让你笑和哭的人不多，大部分的人都只会让你不痛不痒。——朱德庸",
    "太至人话得不像自己，思想是别人的忘见。生活是別人的模仿，情感是別人的引述。 ——王尔德",
    "每个人都有自己的天赋。如果用会不会爬树的能力去评判一条鱼，它终其一生以为自己愚蠢。——爱因斯坦",
    "雨下给富人，也下给穷人，下给义人，也下给不义的人；其实，雨并不公道，因为下落在一个没有公道的世界上。——老舍",
    "人生不过如此，且行且珍惜。自己永远是自己的主角，不要总在别人的戏剧里充当着配角。——林语堂",
    "不幸，是天才的进身之阶，信徒的洗礼之水，能人的无价之宝，弱者的无底深渊。——巴尔扎克《人间喜剧》",
    "最可怜的人不是那些有错误的思想方式的人们，而是那些没有任何一定的、彻底的思想方式的人们。——车尔尼雪夫斯基",
    "快乐既然是人类和兽类所共同追求的东西，所以从某种意义上说，它就是最高的善。——亚里士多德",
    "快乐既然是人类和兽类所共同追求的东西，所以从某种意义上说，它就是最高的善。——亚里士多德",
  ]; // 可以通过改变数组内容，对名言或诗词进行增删
  return quoteArr[Math.floor(Math.random() * quoteArr.length)]; // 数组中随机取一个元素
}

export function millsToTime(mills) {
  if (!mills) {
    return "";
  }
  let s = mills / 1000;
  if (s < 60) {
    return s.toFixed(0) + " 秒";
  }
  let m = s / 60;
  if (m < 60) {
    return m.toFixed(0) + " 分钟";
  }
  let h = m / 60;
  if (h < 24) {
    return h.toFixed(0) + " 小时";
  }
  let d = h / 24;
  if (d < 30) {
    return d.toFixed(0) + " 天";
  }
  let month = d / 30;
  if (month < 12) {
    return month.toFixed(0) + " 个月";
  }
  let year = month / 12;
  return year.toFixed(0) + " 年";
}
export function timeFix() {
  const time = new Date();
  const hour = time.getHours();
  return hour < 9
    ? "早上好"
    : hour <= 11
    ? "上午好"
    : hour <= 13
    ? "中午好"
    : hour < 20
    ? "下午好"
    : "晚上好";
}
/*
 * 智能机浏览器版本信息:
 *
 */
export const ande_browser = {
  versions: (function () {
    var u = navigator.userAgent,
      app = navigator.appVersion;
    return {
      //移动终端浏览器版本信息
      trident: u.indexOf("Trident") > -1, //IE内核
      presto: u.indexOf("Presto") > -1, //opera内核
      webKit: u.indexOf("AppleWebKit") > -1, //苹果、谷歌内核
      gecko: u.indexOf("Gecko") > -1 && u.indexOf("KHTML") == -1, //火狐内核
      mobile: !!u.match(/AppleWebKit.*Mobile.*/) || u.indexOf("iPad") > -1, //是否为移动终端
      ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
      android: u.indexOf("Android") > -1 || u.indexOf("Linux") > -1, //android终端或者uc浏览器
      iPhone: u.indexOf("iPhone") > -1, //是否为iPhone或者QQHD浏览器
      // iPad: u.indexOf('Android') > -1, //是否iPad
      iPad: u.indexOf("iPad") > -1 || u.indexOf("Android") > -1, //是否iPad
      webApp: u.indexOf("Safari") == -1, //是否web应该程序，没有头部与底部
    };
  })(),
  language: (navigator.browserLanguage || navigator.language).toLowerCase(),
};
/**
 * 是否为移动终端
 */
export function isMobile() {
  return ande_browser.versions.mobile;
}

/**
 * 下载文件 用于excel导出
 * @param url
 * @param parameter
 * @returns {*}
 */
export function downFile(
  url: string,
  parameter: object,
  timeout: number = 9000
) {
  console.log(
    "%c [ parameter ]-154",
    "font-size:13px; background:#15e18a; color:#59ffce;",
    parameter
  );

  return service.request({
    url: url,
    params: parameter,
    method: "get",
    responseType: "blob",
    timeout: timeout,
  });
}
/**
 * 下载文件 用于excel导出
 * @param url
 * @param parameter
 * @returns {*}
 */
export function downFilePost(
  url: string,
  data: object,
  timeout: number = 9000
) {
  return service({
    url: url,
    data: data,
    method: "post",
    responseType: "blob",
    timeout: timeout,
  });
}
/**
 * 文件上传 用于富文本上传图片
 * @param url
 * @param parameter
 * @returns {*}
 */
export function uploadAction(url: string, parameter: object) {
  return service({
    url: url,
    data: parameter,
    method: "post",
    headers: {
      "Content-Type": "multipart/form-data", // 文件上传
    },
  });
}

/**
 * 下载文件
 * @param url 文件路径
 * @param fileName 文件名
 * @param parameter
 * @returns {*}
 */
export function downloadFile(url: string, fileName: string, parameter: object) {
  return downFile(url, parameter).then((data: any) => {
    if (!data || data.size === 0) {
      // Vue.prototype['$message'].warning('文件下载失败')
      // message.warning("文件下载失败");
      createMessage.warning("文件下载失败")
      return;
    }
    if (typeof window.navigator.msSaveBlob !== "undefined") {
      window.navigator.msSaveBlob(new Blob([data]), fileName);
    } else {
      let url = window.URL.createObjectURL(new Blob([data]));
      let link = document.createElement("a");
      link.style.display = "none";
      link.href = url;
      link.setAttribute("download", fileName);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link); //下载完成移除元素
      window.URL.revokeObjectURL(url); //释放掉blob对象
    }
  });
}
/**
 * 下载文件
 * @param url 文件路径
 * @param fileName 文件名
 * @param parameter
 * @returns {*}
 */
export function exportExcel(url: string, fileName: string, parameter: object) {
  let realUrl = getAppEnvConfig().VITE_GLOB_DOMAIN_URL + url;
  downFile(realUrl, parameter).then((data: any) => {
    if (!data) {
      createMessage.warning("文件下载失败");
      return;
    }
    if (typeof window.navigator.msSaveBlob !== "undefined") {
      window.navigator.msSaveBlob(
        new Blob([data], {
          type: "application/vnd.ms-excel",
        }),
        fileName + ".xls"
      );
    } else {
      let url = window.URL.createObjectURL(
        new Blob([data], {
          type: "application/vnd.ms-excel",
        })
      );
      let link = document.createElement("a");
      link.style.display = "none";
      link.href = url;
      link.setAttribute("download", fileName + ".xls");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link); //下载完成移除元素
      window.URL.revokeObjectURL(realUrl); //释放掉blob对象
    }
  });
}
/**
 * 获取文件服务访问路径
 * @param avatar
 * @param subStr
 * @returns {*}
 */
export function getFileAccessHttpUrl(avatar?: string, subStr?: string) {
  if (!subStr) subStr = "http";
  try {
    if (avatar && avatar.startsWith(subStr)) {
      return avatar;
    } else {
      if (avatar && avatar.length > 0 && avatar.indexOf("[") == -1) {
        return getApp()._CONFIG["staticDomainURL"] + "/" + avatar;
      }
    }
  } catch (err) {
    return;
  }
}

/**
 * 获取实体属性值 通过类型约束
 * @param o 对象实体 {name:'张伟}
 * @param name 属性key值
 */
export function getValue<T extends object, K extends keyof T>(
  o: T,
  name: K
): T[K] {
  return o[name];
}

/**
 * 两个字符串是否相似  str2里面是否包含 str1
 * @param {Object} str1
 * @param {Object} str2
 */
export function like(str1: string, str2: string) {
  str1 = String(str1).toLowerCase();
  str2 = String(str2).toLowerCase();
  var result = str2.indexOf(str1); //其实就是类似contain()方法，找到str2里面是否包含有str1，不存在返回-1
  if (result >= 0) {
    return true;
  } else {
    return false;
  }
  return false;
}
/**
 * 深度克隆对象、数组
 * @param obj 被克隆的对象
 * @return 克隆后的对象
 */
export const cloneObject = <T>(obj: T): T => {
  return JSON.parse(JSON.stringify(obj));
};
/**
 * 全局安装组件
 * @param component 组件
 * @param alias 别名
 */
export const withInstall = <T>(component: T, alias?: string) => {
  const comp = component as any;
  comp.install = (app: App) => {
    app.component(comp.name || comp.displayName, component);
    if (alias) {
      app.config.globalProperties[alias] = component;
    }
  };
  return component as T & Plugin;
};
/**
 * 深度合并
 * @param src 原始数据
 * @param target  目标数
 */
export function deepMerge<T = any>(src: any = {}, target: any = {}): T {
  let key: string;
  for (key in target) {
    src[key] = isObject(src[key])
      ? deepMerge(src[key], target[key])
      : (src[key] = target[key]);
  }
  return src;
}
/**
 * 获取url地址参数
 * @param paraName
 */
export function getUrlParam(paraName: string) {
  let url = document.location.toString();
  let arrObj = url.split("?");

  if (arrObj.length > 1) {
    let arrPara = arrObj[1].split("&");
    let arr;

    for (let i = 0; i < arrPara.length; i++) {
      arr = arrPara[i].split("=");

      if (arr != null && arr[0] == paraName) {
        return arr[1];
      }
    }
    return "";
  } else {
    return "";
  }
}

/**
 * 根据腾讯定位获取文字描述
 * @param a_txLocation 腾讯定位
 */
export function getLocationTextByTxLocation(
  a_txLocation?: NsSystem.txLocation
) {
  let r_text = "";
  if (a_txLocation && a_txLocation.status == 0) {
    r_text = `${a_txLocation.result.ad_info.city}  ${a_txLocation.result.ad_info.district}`;
  }

  return r_text;
}

/**
 *
 * @param a_result 转化到ipage
 */
export function covertIPage<T>(a_result: any): NSAPI.IPageResult {
  return a_result;
}
/**
 * 是否显示
 * @param a_row
 * @param a_queryParams
 */
export const canShowBySearch = (a_row: any, a_queryParams: any) => {
  let flagShow: boolean = true;
  let params = a_queryParams;
  //基础查询条件
  let basicQuerys = ["pageSize", "pageNo", "column", "order"];
  Object.keys(params).map((keys) => {
    if (basicQuerys.includes(keys)) {
      return;
    }
    if (params[keys]) {
      if (params[keys] != undefined && params[keys] != "") {
        if (Array.isArray(params[keys])) {
          if (!a_row[keys] || !params[keys].includes(a_row[keys])) {
            flagShow = false;
          }
        } else {
          if (!a_row[keys] || !like(params[keys], a_row[keys])) {
            flagShow = false;
          }
        }
      }
    }
  });

  return flagShow;
};
/**
 *
 * @param a_chatGroup  群聊
 * @param a_userId  群聊里的用户id
 * @returns
 */
export function zw_getUserByChatGroup(
  a_chatGroup: ChatGroup,
  a_userId: string
): SysUser {
  let userList: SysUser = {};
  if (a_chatGroup.groupid) {
    a_chatGroup.sysUserList?.map((items) => {
      if (a_userId == items.id) {
        userList = items;
      }
    });
  }
  return userList;
}

/**
 * 获取参数配置值
 * @param a_key 參數key
 */
export function getSysConfig(a_key: string) {
  return useSystemStoreWithOut().sysConfigList?.find((v_sysConfig) => {
    return v_sysConfig.configKey == a_key;
  })?.configValue;
}


export function timeSlot(step: number) {
  //  step = 间隔的分钟
  var date = new Date();
  date.setHours(0); // 时分秒设置从零点开始
  date.setSeconds(0);
  date.setUTCMinutes(0);
  // console.log(date.getHours())
  // console.log(date.getSeconds())
  // console.log(new Date(date.getTime()))

  var arr = [],
    timeArr = [];
  var slotNum = (24 * 60) / step; // 算出多少个间隔
  for (var f = 0; f < slotNum; f++) {
    //  stepM * f = 24H*60M
    // arr.push(new Date(Number(date.getTime()) + Number(step*60*1000*f)))   //  标准时间数组
    var time = new Date(Number(date.getTime()) + Number(step * 60 * 1000 * f)); // 获取：零点的时间 + 每次递增的时间
    var hour: number | string = "",
      sec: number | string = "";
    time.getHours() < 10
      ? (hour = "0" + time.getHours())
      : (hour = time.getHours()); // 获取小时
    time.getMinutes() < 10
      ? (sec = "0" + time.getMinutes())
      : (sec = time.getMinutes()); // 获取分钟
    timeArr.push(hour + ":" + sec);
  }
  return timeArr;
}

/**
 * 判断为白天还是夜间
 */
export function isDaylight() {
  let curDate = new Date();
  if (curDate.getHours() >= 23 || curDate.getHours() < 7) {
    return false;
  } else {
    return true;
  }
}
/**
 * 根据天气获取icon
 * @param a_weather
 */
type gdWeatherCateZh = keyof typeof ande_const.iconWeatherMap;
type gdWeatherCateZhIcon = keyof typeof ande_const.iconifyWeather;
export function getWeatherIcon(a_weather: string) {
  let onBehalfOfWeather: gdWeatherCateZh = "晴";
  const weatherObj: { [key: string]: string[] } = ande_const.iconWeatherMap;
  for (let onBehalfOf in weatherObj) {
    let weatherMap: string[] = weatherObj[onBehalfOf];
    if (weatherMap.includes(a_weather)) {
      onBehalfOfWeather = onBehalfOf as gdWeatherCateZh;
      break;
    }
  }
  let weatherIcon: gdWeatherCateZhIcon = "晴";
  if (onBehalfOfWeather == "多云") {
    if (isDaylight()) {
      weatherIcon = "白天多云";
    } else {
      weatherIcon = "夜晚多云";
    }
  } else {
    weatherIcon = onBehalfOfWeather;
  }
  return ande_const.iconifyWeather[weatherIcon];
}

export function getTokenHeader() {
  let token = getAuthCache(TOKEN_KEY);

  let head = {
    "X-Access-Token": token,
  };

  return head;
}
export function formatNumber(num: number, decimals: number = 0) {
  let n_num = num.toFixed(decimals);
  n_num += "";
  const x = n_num.split(".");
  let x1 = x[0];
  const x2 = x.length > 1 ? "." + x[1] : "";
  const rgx = /(\d+)(\d{3})/;
  if ("," && isNaN(parseFloat(","))) {
    while (rgx.test(x1)) {
      x1 = x1.replace(rgx, "$1" + "," + "$2");
    }
  }
  return x1 + x2;
}
/**
 * 预览文件
 * @param a_previewUrl 文件路径
 */
export function previewFile(a_previewUrl: string) {
  console.log(
    "%c [ a_previewUrl ]-138",
    "font-size:13px; background:#31265c; color:#756aa0;",
    a_previewUrl
  );
  window.open(
    "http://8.141.13.247:8221/onlinePreview?url=" +
      encodeURIComponent(Base64.encode(a_previewUrl))
  );
}
// 文件类型判断
export function zw_getFileTypeIcon(a_fileName: string) {
  let fileType = a_fileName.split(".")[a_fileName.split(".").length - 1];
  console.log(
    "%c [ fileType ]-654",
    "font-size:13px; background:#cadceb; color:#ffffff;",
    fileType
  );
  let foldPath = "/images/filetype/";
  if (fileType) {
    const map = [
      [() => fileType.includes("pdf"), () => foldPath + "PPT.png"],
      [() => ["docx", "doc"].includes(fileType), () => foldPath + "word.png"],
      [() => ["xlsx", "xls"].includes(fileType), () => foldPath + "excel.png"],
      [
        () => ["mp4", "MP4", "MOV"].includes(fileType),
        () => foldPath + "MP4.png",
      ],
      [() => fileType.includes("mp3"), () => foldPath + "mp3.png"],
      [
        () =>
          ["jpg", "JPG", "jpeg", "JPEG", "png", "PNG", "gif", "GIF"].includes(
            fileType
          ),
        () => foldPath + "picture.png",
      ],
      [() => ["ppt", "pptx"].includes(fileType), () => foldPath + "PPT.png"],
    ];
    const target = map.find((m) => m[0]());
    if (target) {
      console.log(
        "%c [ target ]-681",
        "font-size:13px; background:#178952; color:#5bcd96;",
        target
      );

      return target[1]();
    } else {
      return foldPath + "file.png";
    }
  }
}

export function zw_getFileSize(limit) {
  var size = "";
  if (limit < 0.1 * 1024) {
    //小于0.1KB，则转化成B
    size = limit.toFixed(2) + "B";
  } else if (limit < 0.1 * 1024 * 1024) {
    //小于0.1MB，则转化成KB
    size = (limit / 1024).toFixed(2) + "KB";
  } else if (limit < 0.1 * 1024 * 1024 * 1024) {
    //小于0.1GB，则转化成MB
    size = (limit / (1024 * 1024)).toFixed(2) + "MB";
  } else {
    //其他转化成GB
    size = (limit / (1024 * 1024 * 1024)).toFixed(2) + "GB";
  }

  var sizeStr = size + ""; //转成字符串
  var index = sizeStr.indexOf("."); //获取小数点处的索引
  var dou = sizeStr.substr(index + 1, 2); //获取小数点后两位的值
  if (dou == "00") {
    //判断后两位是否为00，如果是则删除00
    return sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2);
  }
  return size;
}
/**
 * 获取工作流bizparams taskId
 * @param a_bizParams
 * @returns
 */
export function zw_getTaskIdByBizParams(a_bizParams?: string) {
  let r_taskId;

  if (
    a_bizParams &&
    isJsonObjectString(a_bizParams) &&
    JSON.parse(a_bizParams).taskId
  ) {
    r_taskId = JSON.parse(a_bizParams).taskId;
  }
  return r_taskId;
}
