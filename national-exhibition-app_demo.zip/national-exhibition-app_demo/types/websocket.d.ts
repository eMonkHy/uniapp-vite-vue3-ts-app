/**
 * 消息通知  websocket
 */
declare namespace AndeWebsocket {
  enum updateDict {
    updateProcess,
  }
  /**
   * 消息通知接收内容基类
   */
  interface WebsocketData {
    cmd: string | { cmd: string }
  }

  /**
   * 后台返回的消息整体 包含data
   */
  interface WebsocketHandleData {
    data: WebsocketData
  }
}
