import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import uni from "@dcloudio/vite-plugin-uni";
import * as path from "path";
import Components from "unplugin-vue-components/vite";
import { NutResolver } from "nutui-uniapp";
import vueJsx from "@vitejs/plugin-vue-jsx";
import AutoImport from "unplugin-auto-import/vite";
import PxToViewport from "postcss-px-to-viewport";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    // 开启 unplugin 插件，自动引入 NutUI 组件
    Components({
      resolvers: [NutResolver()],
    }),
    // 注意，UniApp插件一定要放到后面！
    vueJsx({
      // options are passed on to @vue/babel-plugin-jsx
    }),
    AutoImport({
      imports: [
        "vue",
        "@vueuse/core",
        "uni-app",
        "pinia",
        {
          "nutui-uniapp/composables": ["useToast"],
        },
      ],
      dirs: ["./composables/**"],
    }),
    uni(),
  ],
  css: {
    preprocessorOptions: {
      scss: {
        additionalData: `@import "nutui-uniapp/styles/variables.scss";`,
      },
    },
    postcss: {
      plugins: [
        PxToViewport({
          viewportWidth: 375,
        }),
      ],
    },
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
      "#": path.resolve(__dirname, "types"),
    },
  },
});
